package org.example.economicssimulatorclient.dto;

public record LlmChatResponseDto(
        String assistantMessage
) {}
